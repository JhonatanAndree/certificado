# SISTEMA Certificados y Diplomas
Sistema de emisión y administración de diplomas y certificados para optar el título técnico de Computación e Informática MGP-2022.

Jhonatan Andree Carrión Neyra